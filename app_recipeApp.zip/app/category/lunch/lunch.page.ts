import { Component} from '@angular/core';
import { ModalController } from '@ionic/angular';

//lunch
import { SaladPage } from '../recipes/salad/salad.page';
import {PrepPage } from '../recipes/prep/prep.page';
import { SkilletPage } from '../recipes/skillet/skillet.page';

@Component({
  selector: 'app-lunch',
  templateUrl: './lunch.page.html',
  styleUrls: ['./lunch.page.scss'],
})


export class LunchPage {

  constructor(private modalCtrl: ModalController) { }


   //Salad

async openSalad() {
  const modal = await this.modalCtrl.create ({
  component: SaladPage
  });

  
  await modal.present();
  }

  //Prep

async openPrep() {
  const modal = await this.modalCtrl.create ({
  component: PrepPage
  });

  
  await modal.present();
  }

  //Skillet

async openSkillet() {
  const modal = await this.modalCtrl.create ({
  component: SkilletPage
  });

  
  await modal.present();
  }


}
