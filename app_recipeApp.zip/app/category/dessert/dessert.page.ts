
import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';

//dessert
import { MuffinPage } from '../recipes/muffin/muffin.page';
import { CakePage } from '../recipes/cake/cake.page';
import { CookiePage } from '../recipes/cookie/cookie.page';

@Component({
  selector: 'app-dessert',
  templateUrl: './dessert.page.html',
  styleUrls: ['./dessert.page.scss'],
})

export class DessertPage {

  constructor(private modalCtrl: ModalController) { }

  //muffin
  async openMuffin() {
  const modal = await this.modalCtrl.create ({
  component: MuffinPage
  });

  
  await modal.present();
  }

//Cake

async openCake() {
  const modal = await this.modalCtrl.create ({
  component: CakePage
  });

  
  await modal.present();
  }

  //Cookie

async openCookie() {
  const modal = await this.modalCtrl.create ({
  component: CookiePage
  });

  
  await modal.present();
  }


}

