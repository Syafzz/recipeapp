import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { YougurtPage } from '../recipes/yougurt/yougurt.page';
import { ButterPage } from '../recipes/butter/butter.page';
import { ApplePage } from '../recipes/apple/apple.page';

@Component({
  selector: 'app-snack',
  templateUrl: './snack.page.html',
  styleUrls: ['./snack.page.scss'],
})
export class SnackPage {

  constructor(private modalCtrl: ModalController) { }

  async openYogurt() {
  const modal = await this.modalCtrl.create ({
  component: YougurtPage
  });

  await modal.present();
  }

  async openButter() {
  const modal = await this.modalCtrl.create ({
  component: ButterPage
  });

  await modal.present();
  }

  async openApple() {
  const modal = await this.modalCtrl.create ({
  component: ApplePage
  });

  await modal.present();
  }

}
