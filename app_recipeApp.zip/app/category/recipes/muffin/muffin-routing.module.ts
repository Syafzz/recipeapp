import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MuffinPage } from './muffin.page';

const routes: Routes = [
  {
    path: '',
    component: MuffinPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MuffinPageRoutingModule {}
