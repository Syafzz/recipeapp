import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-butter',
  templateUrl: './butter.page.html',
  styleUrls: ['./butter.page.scss'],
})
export class ButterPage implements OnInit {

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

  async closeOmelete() {
  await this.modalCtrl.dismiss();
  }

}
