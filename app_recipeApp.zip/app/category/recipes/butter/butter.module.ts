import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ButterPageRoutingModule } from './butter-routing.module';

import { ButterPage } from './butter.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ButterPageRoutingModule
  ],
  declarations: [ButterPage]
})
export class ButterPageModule {}
