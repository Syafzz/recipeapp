import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SkilletPageRoutingModule } from './skillet-routing.module';

import { SkilletPage } from './skillet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SkilletPageRoutingModule
  ],
  declarations: [SkilletPage]
})
export class SkilletPageModule {}
