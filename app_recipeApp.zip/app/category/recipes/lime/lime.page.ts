import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-lime',
  templateUrl: './lime.page.html',
  styleUrls: ['./lime.page.scss'],
})
export class LimePage implements OnInit {

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

  async closeOmelete() {
  await this.modalCtrl.dismiss();
  }

}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lime',
  templateUrl: './lime.page.html',
  styleUrls: ['./lime.page.scss'],
})
export class LimePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
