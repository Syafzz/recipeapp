import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LimePage } from './lime.page';

const routes: Routes = [
  {
    path: '',
    component: LimePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LimePageRoutingModule {}
