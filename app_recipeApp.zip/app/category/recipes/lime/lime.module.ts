import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LimePageRoutingModule } from './lime-routing.module';

import { LimePage } from './lime.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LimePageRoutingModule
  ],
  declarations: [LimePage]
})
export class LimePageModule {}
