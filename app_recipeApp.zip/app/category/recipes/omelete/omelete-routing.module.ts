import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OmeletePage } from './omelete.page';

const routes: Routes = [
  {
    path: '',
    component: OmeletePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OmeletePageRoutingModule {}
