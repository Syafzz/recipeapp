import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OmeletePageRoutingModule } from './omelete-routing.module';

import { OmeletePage } from './omelete.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OmeletePageRoutingModule
  ],
  declarations: [OmeletePage]
})
export class OmeletePageModule {}
