import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-lasagna',
  templateUrl: './lasagna.page.html',
  styleUrls: ['./lasagna.page.scss'],
})
export class LasagnaPage implements OnInit {

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

  async closeOmelete() {
  await this.modalCtrl.dismiss();
  }

}
