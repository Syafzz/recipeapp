import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LasagnaPageRoutingModule } from './lasagna-routing.module';

import { LasagnaPage } from './lasagna.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LasagnaPageRoutingModule
  ],
  declarations: [LasagnaPage]
})
export class LasagnaPageModule {}
