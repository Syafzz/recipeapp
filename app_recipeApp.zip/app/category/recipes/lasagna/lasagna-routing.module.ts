import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LasagnaPage } from './lasagna.page';

const routes: Routes = [
  {
    path: '',
    component: LasagnaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LasagnaPageRoutingModule {}
