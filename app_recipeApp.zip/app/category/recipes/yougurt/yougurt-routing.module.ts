import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { YougurtPage } from './yougurt.page';

const routes: Routes = [
  {
    path: '',
    component: YougurtPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class YougurtPageRoutingModule {}
