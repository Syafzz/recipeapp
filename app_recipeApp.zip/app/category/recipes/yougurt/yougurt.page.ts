import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-yougurt',
  templateUrl: './yougurt.page.html',
  styleUrls: ['./yougurt.page.scss'],
})
export class YougurtPage implements OnInit {

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

  async closeOmelete() {
  await this.modalCtrl.dismiss();
  }

}
