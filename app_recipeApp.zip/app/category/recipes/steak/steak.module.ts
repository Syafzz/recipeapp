import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SteakPageRoutingModule } from './steak-routing.module';

import { SteakPage } from './steak.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SteakPageRoutingModule
  ],
  declarations: [SteakPage]
})
export class SteakPageModule {}
