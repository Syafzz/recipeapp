import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmoothiePage } from './smoothie.page';

const routes: Routes = [
  {
    path: '',
    component: SmoothiePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmoothiePageRoutingModule {}
