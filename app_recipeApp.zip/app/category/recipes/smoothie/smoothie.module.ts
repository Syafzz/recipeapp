import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmoothiePageRoutingModule } from './smoothie-routing.module';

import { SmoothiePage } from './smoothie.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmoothiePageRoutingModule
  ],
  declarations: [SmoothiePage]
})
export class SmoothiePageModule {}
