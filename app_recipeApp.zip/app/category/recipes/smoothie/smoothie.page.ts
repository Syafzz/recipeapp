import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-smoothie',
  templateUrl: './smoothie.page.html',
  styleUrls: ['./smoothie.page.scss'],
})

export class SmoothiePage implements OnInit {

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
  }

  async closeOmelete() {
  await this.modalCtrl.dismiss();
  }

}

