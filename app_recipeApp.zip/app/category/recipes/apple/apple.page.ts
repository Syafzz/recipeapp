import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apple',
  templateUrl: './apple.page.html',
  styleUrls: ['./apple.page.scss'],
})
export class ApplePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
