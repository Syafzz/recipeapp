import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BreakfeastPage } from './breakfeast.page';

const routes: Routes = [
  {
    path: '',
    component: BreakfeastPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BreakfeastPageRoutingModule {}
