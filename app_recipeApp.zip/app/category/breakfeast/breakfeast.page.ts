
import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
//breakfeast
import { OmeletePage } from '../recipes/omelete/omelete.page';
import { WafflePage } from '../recipes/waffle/waffle.page';
import { SmoothiePage } from '../recipes/smoothie/smoothie.page';




@Component({
  selector: 'app-breakfast',
  templateUrl: './breakfeast.page.html',
  styleUrls: ['./breakfeast.page.scss'],
})
export class BreakfeastPage {

  constructor(private modalCtrl: ModalController) { }

  //omelete
  async openOmelete() {
  const modal = await this.modalCtrl.create ({
  component: OmeletePage
  });

  
  await modal.present();
  }

//waffle

async openWaffle() {
  const modal = await this.modalCtrl.create ({
  component: WafflePage
  });

  
  await modal.present();
  }

  //smoothie

async openSmoothie() {
  const modal = await this.modalCtrl.create ({
  component: SmoothiePage
  });

  
  await modal.present();
  }


}
