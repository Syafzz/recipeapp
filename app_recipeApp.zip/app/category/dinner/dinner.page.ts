import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { LasagnaPage } from '../recipes/lasagna/lasagna.page';
import { LimePage } from '../recipes/lime/lime.page';
import { SteakPage } from '../recipes/steak/steak.page';

@Component({
  selector: 'app-dinner',
  templateUrl: './dinner.page.html',
  styleUrls: ['./dinner.page.scss'],
})
export class DinnerPage {

  constructor(private modalCtrl: ModalController) { }

  async openLasagna() {
  const modal = await this.modalCtrl.create ({
  component: LasagnaPage
  });

  await modal.present();
  }

  async openLime() {
  const modal = await this.modalCtrl.create ({
  component: LimePage
  });

  await modal.present();
  }

  async openSteak() {
  const modal = await this.modalCtrl.create ({
  component: SteakPage
  });

  await modal.present();
  }

}