import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage {

  constructor(private router: Router) {}

  openAbout() {
  this.router.navigate(['/about']);
  }

  openMeal() {
  this.router.navigate(['/meal']);
  }

  option={
    slidesPerView:1.6,
    centerdSlides:true,
    loop:true,
    spaceBetween:10,
    //autoplay:true,
  }

}
