import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'about',
    loadChildren: () => import('./about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'recipe',
    loadChildren: () => import('./recipe/recipe.module').then( m => m.RecipePageModule)
  },
  {
    path: 'breakfeast',
    loadChildren: () => import('./category/breakfeast/breakfeast.module').then( m => m.BreakfeastPageModule)
  },
  {
    path: 'lunch',
    loadChildren: () => import('./category/lunch/lunch.module').then( m => m.LunchPageModule)
  },
  {
    path: 'dinner',
    loadChildren: () => import('./category/dinner/dinner.module').then( m => m.DinnerPageModule)
  },
  {
    path: 'snack',
    loadChildren: () => import('./category/snack/snack.module').then( m => m.SnackPageModule)
  },
  {
    path: 'dessert',
    loadChildren: () => import('./category/dessert/dessert.module').then( m => m.DessertPageModule)
  },
  {
    path: 'omelete',
    loadChildren: () => import('./category/recipes/omelete/omelete.module').then( m => m.OmeletePageModule)
  },
  {
    path: 'waffle',
    loadChildren: () => import('./category/recipes/waffle/waffle.module').then( m => m.WafflePageModule)
  },
  {
    path: 'smoothie',
    loadChildren: () => import('./category/recipes/smoothie/smoothie.module').then( m => m.SmoothiePageModule)
  },
  {
    path: 'salad',
    loadChildren: () => import('./category/recipes/salad/salad.module').then( m => m.SaladPageModule)
  },
  {
    path: 'prep',
    loadChildren: () => import('./category/recipes/prep/prep.module').then( m => m.PrepPageModule)
  },
  {
    path: 'skillet',
    loadChildren: () => import('./category/recipes/skillet/skillet.module').then( m => m.SkilletPageModule)
  },
  {
    path: 'lasagna',
    loadChildren: () => import('./category/recipes/lasagna/lasagna.module').then( m => m.LasagnaPageModule)
  },
  {
    path: 'lime',
    loadChildren: () => import('./category/recipes/lime/lime.module').then( m => m.LimePageModule)
  },
  {
    path: 'steak',
    loadChildren: () => import('./category/recipes/steak/steak.module').then( m => m.SteakPageModule)
  },
  {
    path: 'yougurt',
    loadChildren: () => import('./category/recipes/yougurt/yougurt.module').then( m => m.YougurtPageModule)
  },
  {
    path: 'butter',
    loadChildren: () => import('./category/recipes/butter/butter.module').then( m => m.ButterPageModule)
  },
  {
    path: 'apple',
    loadChildren: () => import('./category/recipes/apple/apple.module').then( m => m.ApplePageModule)
  },
  {
    path: 'muffin',
    loadChildren: () => import('./category/recipes/muffin/muffin.module').then( m => m.MuffinPageModule)
  },
  {
    path: 'cake',
    loadChildren: () => import('./category/recipes/cake/cake.module').then( m => m.CakePageModule)
  },
  {
    path: 'cookie',
    loadChildren: () => import('./category/recipes/cookie/cookie.module').then( m => m.CookiePageModule)
  },
  {
    path: 'meal',
    loadChildren: () => import('./meal/meal.module').then( m => m.MealPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
